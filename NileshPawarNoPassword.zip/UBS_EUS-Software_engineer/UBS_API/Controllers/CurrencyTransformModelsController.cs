﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using System.Web.Http.Results;
using UBS_API.CurrencyTransformProxy;
using UBS_API.Entities;
using UBS_API.Models;

namespace UBS_API.Controllers
{
    /// <summary>
    /// CurrencyTransformModelsController API
    /// </summary>
     public class CurrencyTransformModelsController : ApiController
    {
        private UBS_APIContext db;
        private CurrencyTransformClient transformClient;

        public CurrencyTransformModelsController(): this(new CurrencyTransformClient(), new UBS_APIContext())
        {
        }

        public CurrencyTransformModelsController(CurrencyTransformClient currencyTransformClient, UBS_APIContext uBS_APIContext )
        {
            this.db = uBS_APIContext;
            transformClient = currencyTransformClient;
        }
        // GET: api/CurrencyTransformModels
        public IQueryable<CurrencyTransformModel> GetCurrencyTransformModels()
        {
            return db.CurrencyTransformModels;
        }

        // GET: api/CurrencyTransformModels/5
        [ResponseType(typeof(CurrencyTransformModel))]
        public async Task<IHttpActionResult> GetCurrencyTransformModel(int id)
        {
            CurrencyTransformModel currencyTransformModel = await db.CurrencyTransformModels.FindAsync(id);
            if (currencyTransformModel == null)
            {
                return NotFound();
            }

            return Ok(currencyTransformModel);
        }

        // PUT: api/CurrencyTransformModels/5
        [ResponseType(typeof(void))]
        public async Task<IHttpActionResult> PutCurrencyTransformModel(int id, CurrencyTransformModel currencyTransformModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != currencyTransformModel.Id)
            {
                return BadRequest();
            }

            db.Entry(currencyTransformModel).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CurrencyTransformModelExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/CurrencyTransformModels
        [ResponseType(typeof(CurrencyTransformModel))]
        public async Task<IHttpActionResult> PostCurrencyTransformModel(CurrencyTransformModel currencyTransformModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            string result = "";
            double dblAmmount;
            int ammount;

            if (int.TryParse(currencyTransformModel.Currency, out ammount))
            {
                result = await transformClient.HumanizeAsync(ammount);
            }
            else if (double.TryParse(currencyTransformModel.Currency, out dblAmmount))
            {
                result = await transformClient.HumanizeDoubleAsync(dblAmmount);
            }

            currencyTransformModel.CurrencyInWords = result;
            db.CurrencyTransformModels.Add(currencyTransformModel);
            await db.SaveChangesAsync();

            return CreatedAtRoute("DefaultApi", new { id = currencyTransformModel.Id }, currencyTransformModel);
        }

        // DELETE: api/CurrencyTransformModels/5
        [ResponseType(typeof(CurrencyTransformModel))]
        public async Task<IHttpActionResult> DeleteCurrencyTransformModel(int id)
        {
            CurrencyTransformModel currencyTransformModel = await db.CurrencyTransformModels.FindAsync(id);
            if (currencyTransformModel == null)
            {
                return NotFound();
            }

            db.CurrencyTransformModels.Remove(currencyTransformModel);
            await db.SaveChangesAsync();

            return Ok(currencyTransformModel);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool CurrencyTransformModelExists(int id)
        {
            return db.CurrencyTransformModels.Count(e => e.Id == id) > 0;
        }
    }
}
﻿using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using UBS_TransformService.Services;

namespace UBS_API.Test
{
    [TestClass]
    public class CurrencyTransformTest
    {
        [TestMethod]
        public void TestHumanize()
        {

            var currencyTransform  = new CurrencyTransform();
            var input = 1;
            var expectedCurrencyConversion = "one";
            var result = currencyTransform.Humanize(input);
            Assert.IsNotNull(result);
            Assert.AreEqual(expectedCurrencyConversion, result);
        }

        [TestMethod]
        public void TestHumanizeDouble()
        {

            var currencyTransform = new CurrencyTransform();
            var input = 10.2;
            var expectedCurrencyConversion = "ten point two";
            var result = currencyTransform.Humanize(input);
            Assert.IsNotNull(result);
            Assert.AreEqual(expectedCurrencyConversion, result);
        }

        [TestMethod]
        public void TestHumanizeInvalidDouble()
        {
            var currencyTransform = new CurrencyTransform();
            var input = 20.0;
            var expectedCurrencyConversion = "";
            var result = currencyTransform.Humanize(input);
            Assert.IsNotNull(result);
            Assert.AreEqual(expectedCurrencyConversion, result);
        }
    }
}
